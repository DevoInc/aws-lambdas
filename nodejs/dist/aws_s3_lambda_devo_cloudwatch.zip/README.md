Version 1.0 - Published 2019.06.25

CONTENTS OF ZIP FILE
/certs 			(this is where you should save your Devo domain certificate files)
/node_modules 	(function source code)
index.js 		(primary configuration file)
package.json
README.txt 

Please follow the complete instructions found on the Devo documentation site.
https://docs.devo.com/confluence/display/NDT/cloud.aws.cloudtrail.events

This procedure describes steps to take in the AWS CloudTrail console. While we make every effort to keep our documentation up to date, it's possible that at some point these instructions no longer perfectly reflect the CloudTrail console's UI. If you notice any inconsistencies, please drop us a note at documentation@devo.com.  