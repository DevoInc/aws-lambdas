__description__ = 'Devo Python Library.'
__url__ = 'http://www.devo.com'
__version__ = "3.4.1"
__author__ = 'Devo'
__author_email__ = 'support@devo.com'
__license__ = 'MIT'
__copyright__ = 'Copyright 2020 Devo'
